/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Affirmation, UserProgress } from './types';

export const AFFIRMATIONS: Affirmation[] = [
  // CONFIDENCE (category: confidence)
  {
    id: 'conf-1',
    text: 'I command my space with stillness, certainty, and an unwavering belief in my capability.',
    category: 'confidence',
    author: 'Self-Certainty',
    gradientFrom: '#1c1917', // stone-900
    gradientTo: '#2e1905', // deep brown amber
    glowColor: 'rgba(245, 158, 11, 0.15)'
  },
  {
    id: 'conf-2',
    text: 'I release the need to prove myself. My competence is quiet, deep, and undeniable.',
    category: 'confidence',
    author: 'Quiet Strength',
    gradientFrom: '#121212',
    gradientTo: '#1e1b4b', // deep indigo/indigo-950
    glowColor: 'rgba(99, 102, 241, 0.12)'
  },
  {
    id: 'conf-3',
    text: 'I step forward into uncertainty with steady focus, knowing my intuition is my compass.',
    category: 'confidence',
    author: 'Bold Presence',
    gradientFrom: '#0a0a0a',
    gradientTo: '#3c1053', // deep violet
    glowColor: 'rgba(168, 85, 247, 0.12)'
  },
  {
    id: 'conf-4',
    text: 'My voice is worthy of space. I speak with intention, clarity, and authority.',
    category: 'confidence',
    author: 'Inner Voice',
    gradientFrom: '#18181b', // zinc-900
    gradientTo: '#451a03', // orange-950
    glowColor: 'rgba(249, 115, 22, 0.15)'
  },
  {
    id: 'conf-5',
    text: 'I am the architect of my security. No external opinion can compromise my foundation.',
    category: 'confidence',
    author: 'Impervious',
    gradientFrom: '#09090b',
    gradientTo: '#27272a',
    glowColor: 'rgba(212, 175, 55, 0.12)'
  },

  // SUCCESS (category: success)
  {
    id: 'succ-1',
    text: 'My energy is structured and aligned. I naturally attract premium opportunities.',
    category: 'success',
    author: 'Refinement',
    gradientFrom: '#141414',
    gradientTo: '#342205', // rich old gold
    glowColor: 'rgba(212, 175, 55, 0.18)'
  },
  {
    id: 'succ-2',
    text: 'I construct masterpieces through consistent focus, masterfully handling one step at a time.',
    category: 'success',
    author: 'Craftsmanship',
    gradientFrom: '#0c0a09',
    gradientTo: '#291305',
    glowColor: 'rgba(234, 179, 8, 0.12)'
  },
  {
    id: 'succ-3',
    text: 'I measure success by my peace, my resilience, and the relentless quality of my execution.',
    category: 'success',
    author: 'Virtue',
    gradientFrom: '#000000',
    gradientTo: '#1c1917',
    glowColor: 'rgba(255, 255, 255, 0.08)'
  },
  {
    id: 'succ-4',
    text: 'My professional life is characterized by integrity, excellence, and effortless growth.',
    category: 'success',
    author: 'Legacy',
    gradientFrom: '#111827', // slate
    gradientTo: '#1e1b4b',
    glowColor: 'rgba(59, 130, 246, 0.12)'
  },
  {
    id: 'succ-5',
    text: 'I translate grand visions into daily realities with flawless precision and poise.',
    category: 'success',
    author: 'The Architect',
    gradientFrom: '#171717',
    gradientTo: '#311005',
    glowColor: 'rgba(245, 158, 11, 0.15)'
  },

  // HEALTH (category: health)
  {
    id: 'heal-1',
    text: 'I honor my physical vessel by providing it with rest, nourishment, and conscious movement.',
    category: 'health',
    author: 'Rejuvenation',
    gradientFrom: '#090d16',
    gradientTo: '#042f2e', // deep teal
    glowColor: 'rgba(20, 184, 166, 0.15)'
  },
  {
    id: 'heal-2',
    text: 'With every breath, vital energy flows into my cells, restoring balance, rhythm, and clarity.',
    category: 'health',
    author: 'Vitality',
    gradientFrom: '#020617',
    gradientTo: '#14532d', // green-950
    glowColor: 'rgba(34, 197, 94, 0.12)'
  },
  {
    id: 'heal-3',
    text: 'My body is designed for self-healing. I listen to its wisdom and give it space to thrive.',
    category: 'health',
    author: 'Wisdom',
    gradientFrom: '#141414',
    gradientTo: '#1c2e24',
    glowColor: 'rgba(16, 185, 129, 0.14)'
  },
  {
    id: 'heal-4',
    text: 'My mind acts as a tranquil sanctuary, promoting nervous system healing and profound ease.',
    category: 'health',
    author: 'Sanctuary',
    gradientFrom: '#020617',
    gradientTo: '#1e293b',
    glowColor: 'rgba(148, 163, 184, 0.1)'
  },

  // GRATITUDE (category: gratitude)
  {
    id: 'grat-1',
    text: 'I gaze upon the tapestry of my life and find deep appreciation for its lessons and beauties.',
    category: 'gratitude',
    author: 'Awareness',
    gradientFrom: '#1c1917',
    gradientTo: '#451a03',
    glowColor: 'rgba(249, 115, 22, 0.12)'
  },
  {
    id: 'grat-2',
    text: 'I appreciate the silent, simple blessings: breath, shelter, light, and conscious heartbeat.',
    category: 'gratitude',
    author: 'Humility',
    gradientFrom: '#0f172a',
    gradientTo: '#2e1065',
    glowColor: 'rgba(139, 92, 246, 0.12)'
  },
  {
    id: 'grat-3',
    text: 'The absolute richness of life lies within my current moment. I am rich, right here and now.',
    category: 'gratitude',
    author: 'Abundance',
    gradientFrom: '#0a0a0a',
    gradientTo: '#2a1a08',
    glowColor: 'rgba(217, 119, 6, 0.15)'
  },
  {
    id: 'grat-4',
    text: 'I acknowledge the giants upon whose shoulders I stand, and I pay forward their goodness.',
    category: 'gratitude',
    author: 'Honor',
    gradientFrom: '#18181b',
    gradientTo: '#1c1917',
    glowColor: 'rgba(255, 255, 255, 0.05)'
  },

  // STUDY (category: study)
  {
    id: 'stud-1',
    text: 'My focus is singular. I digest complex wisdom and absorb knowledge with razor precision.',
    category: 'study',
    author: 'Absorption',
    gradientFrom: '#0b0f19',
    gradientTo: '#172554', // deep blue
    glowColor: 'rgba(59, 130, 246, 0.15)'
  },
  {
    id: 'stud-2',
    text: 'I cultivate curiosity. Learning is my natural lifelong expansion, executed with joy.',
    category: 'study',
    author: 'Intellect',
    gradientFrom: '#08090a',
    gradientTo: '#1e1b4b',
    glowColor: 'rgba(129, 140, 248, 0.15)'
  },
  {
    id: 'stud-3',
    text: 'Wisdom is built layer by layer, brick by brick. My study practices are systematic and refined.',
    category: 'study',
    author: 'Acquisition',
    gradientFrom: '#1c1917',
    gradientTo: '#1e293b',
    glowColor: 'rgba(100, 116, 139, 0.1)'
  },
  {
    id: 'stud-4',
    text: 'Errors are crucial data points. I correct my understanding with patience and intelligence.',
    category: 'study',
    author: 'Patience',
    gradientFrom: '#111827',
    gradientTo: '#115e59',
    glowColor: 'rgba(20, 184, 166, 0.12)'
  },

  // DISCIPLINE (category: discipline)
  {
    id: 'disc-1',
    text: 'My actions originate from clarity and commitment, never fleeting moods or convenience.',
    category: 'discipline',
    author: 'Sovereign',
    gradientFrom: '#090505',
    gradientTo: '#3f0712', // deep dark red
    glowColor: 'rgba(239, 68, 68, 0.15)'
  },
  {
    id: 'disc-2',
    text: 'I choose temporary restraint over endless distraction. I safeguard my higher focus.',
    category: 'discipline',
    author: 'Temperance',
    gradientFrom: '#141414',
    gradientTo: '#2e1005',
    glowColor: 'rgba(245, 158, 11, 0.12)'
  },
  {
    id: 'disc-3',
    text: 'Consistency is my luxury trait. I show up and execute when nobody is watching.',
    category: 'discipline',
    author: 'Excellence',
    gradientFrom: '#020617',
    gradientTo: '#1e293b',
    glowColor: 'rgba(148, 163, 184, 0.15)'
  },
  {
    id: 'disc-4',
    text: 'My mind dictates my actions. My physical body complies with absolute cooperation.',
    category: 'discipline',
    author: 'Command',
    gradientFrom: '#010101',
    gradientTo: '#27272a',
    glowColor: 'rgba(212, 175, 55, 0.12)'
  },
  {
    id: 'disc-5',
    text: 'Success is a simple arithmetic of small choices made daily with resolute adherence.',
    category: 'discipline',
    author: 'Execution',
    gradientFrom: '#121214',
    gradientTo: '#1f1303',
    glowColor: 'rgba(245, 158, 11, 0.1)'
  },

  // SELF-LOVE (category: self-love)
  {
    id: 'love-1',
    text: 'I am highly worthy of my own respect. I forgive my setbacks and praise my resilience.',
    category: 'self-love',
    author: 'Composure',
    gradientFrom: '#141113',
    gradientTo: '#4c0519', // deep rose-950
    glowColor: 'rgba(244, 63, 127, 0.14)'
  },
  {
    id: 'love-2',
    text: 'I protect my sacred sanity. I state my boundaries with grace, certainty, and calm.',
    category: 'self-love',
    author: 'Guardian',
    gradientFrom: '#0d0d0d',
    gradientTo: '#3b0764',
    glowColor: 'rgba(168, 85, 247, 0.12)'
  },
  {
    id: 'love-3',
    text: 'I celebrate the unique path I carve. I do not compete; my standard is entirely my own.',
    category: 'self-love',
    author: 'Authenticity',
    gradientFrom: '#111827',
    gradientTo: '#312e81', // indigo-950
    glowColor: 'rgba(99, 102, 241, 0.12)'
  },
  {
    id: 'love-4',
    text: 'I am inherently enough. The value of my identity does not fluctuate with productivity.',
    category: 'self-love',
    author: 'Intrinsic',
    gradientFrom: '#120516',
    gradientTo: '#1c1917',
    glowColor: 'rgba(212, 175, 55, 0.12)'
  },

  // FITNESS (category: fitness)
  {
    id: 'fit-1',
    text: 'Strength, stamina, and biological excellence reside in every muscle fiber I challenge.',
    category: 'fitness',
    author: 'Fortitude',
    gradientFrom: '#090500',
    gradientTo: '#451a03', // orange/amber-950
    glowColor: 'rgba(245, 158, 11, 0.18)'
  },
  {
    id: 'fit-2',
    text: 'I break barriers with physical exertion, honoring my athletic inheritance.',
    category: 'fitness',
    author: 'Athleticism',
    gradientFrom: '#050a0f',
    gradientTo: '#0c4a6e', // sky-950
    glowColor: 'rgba(14, 165, 233, 0.15)'
  },
  {
    id: 'fit-3',
    text: 'My sweat represents a sacred transaction of effort for absolute longevity and power.',
    category: 'fitness',
    author: 'Transaction',
    gradientFrom: '#141414',
    gradientTo: '#450a0a', // red-950
    glowColor: 'rgba(239, 68, 68, 0.15)'
  },
  {
    id: 'fit-4',
    text: 'I move with fluidity, power, and elegant precision. My power grows daily.',
    category: 'fitness',
    author: 'Fluid Power',
    gradientFrom: '#090d16',
    gradientTo: '#115e59',
    glowColor: 'rgba(20, 184, 166, 0.15)'
  }
];

// Helper to calculate a stable "Affirmation of the Day" using date hash
export function getAffirmationOfTheDay(dateString: string): Affirmation {
  // Use a hash of the date string to select an index
  let hash = 0;
  for (let i = 0; i < dateString.length; i++) {
    hash = dateString.charCodeAt(i) + ((hash << 5) - hash);
  }
  const index = Math.abs(hash) % AFFIRMATIONS.length;
  return AFFIRMATIONS[index];
}

// Format date to local YYYY-MM-DD
export function getLocalDateString(dateStr?: string | Date): string {
  const d = dateStr ? new Date(dateStr) : new Date();
  
  // Use local time zone
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const r = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${r}`;
}

export const INITIAL_USER_PROGRESS: UserProgress = {
  onboardingCompleted: false,
  name: '',
  favorites: [],
  streakCount: 0,
  lastActiveDate: '',
  readHistory: [],
  preferredCategory: 'all',
  fontStyle: 'serif'
};

export const MILESTONES = [
  { days: 1, message: 'First Step taken. A journey of self-actualization begins now.', label: 'Awakening' },
  { days: 3, message: 'Consistency locked. Your cellular rhythm is adjusting.', label: 'Rhythm' },
  { days: 5, message: 'Unbreakable routine. The mind obeys steady commitments.', label: 'Resolute' },
  { days: 7, message: 'Noble Golden Week. One entire week of pristine luxury alignment.', label: 'Sovereign' },
  { days: 14, message: 'Deep Neuropathic Forge. Two weeks of rewriting subconscious programs.', label: 'Mastery' },
  { days: 30, message: 'Transcendence Achieved. The new baseline is now fully integrated.', label: 'Transcendence' }
];

export function getMilestoneForStreak(streak: number) {
  // Return active milestone
  const sorted = [...MILESTONES].reverse();
  const matched = sorted.find(m => streak >= m.days);
  return matched || { days: 0, message: 'Stay intentional. The next milestone is 1 day.', label: 'Beginner' };
}
