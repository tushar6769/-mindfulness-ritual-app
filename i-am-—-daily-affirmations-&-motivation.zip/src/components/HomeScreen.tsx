/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Sparkles, 
  Crown, 
  ShieldCheck, 
  HeartPulse, 
  Sun, 
  BookOpen, 
  Flame, 
  Heart, 
  Dumbbell, 
  ArrowRight,
  ChevronRight,
  TrendingUp,
  Volume2,
  VolumeX
} from 'lucide-react';
import { Affirmation, UserProgress } from '../types';
import { getAffirmationOfTheDay, getLocalDateString } from '../data';

interface HomeScreenProps {
  progress: UserProgress;
  onChangeTab: (tab: 'home' | 'explore' | 'saved' | 'streak') => void;
  onSelectCategory: (category: string) => void;
  onOpenImmersive: (affirmation: Affirmation) => void;
}

const CATEGORIES_MAPPING = [
  { id: 'self-love', label: 'Self Love', icon: Heart, color: 'text-rose-400', bg: 'bg-rose-500/10 border-rose-500/15' },
  { id: 'confidence', label: 'Confidence', icon: ShieldCheck, color: 'text-amber-400', bg: 'bg-amber-500/10 border-amber-500/15' },
  { id: 'success', label: 'Success', icon: Crown, color: 'text-yellow-400', bg: 'bg-yellow-500/10 border-yellow-500/15' },
  { id: 'discipline', label: 'Discipline', icon: Flame, color: 'text-orange-400', bg: 'bg-orange-500/10 border-orange-500/15' },
  { id: 'fitness', label: 'Fitness', icon: Dumbbell, color: 'text-red-400', bg: 'bg-red-500/10 border-red-500/15' },
  { id: 'gratitude', label: 'Gratitude', icon: Sun, color: 'text-amber-300', bg: 'bg-amber-500/10 border-amber-500/15 font-sans' },
  { id: 'health', label: 'Health', icon: HeartPulse, color: 'text-teal-400', bg: 'bg-teal-500/10 border-teal-500/15' },
  { id: 'study', label: 'Study', icon: BookOpen, color: 'text-blue-400', bg: 'bg-blue-500/10 border-blue-500/15 font-sans' },
];

export default function HomeScreen({
  progress,
  onChangeTab,
  onSelectCategory,
  onOpenImmersive
}: HomeScreenProps) {
  const [ambientSound, setAmbientSound] = useState(false);

  // Time-based responsive greeting
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 5 || hour >= 22) return 'Tranquil Night';
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  const todayStr = getLocalDateString();
  const affirmationOfTheDay = getAffirmationOfTheDay(todayStr);

  const handleCategoryClick = (catId: string) => {
    onSelectCategory(catId);
    onChangeTab('explore');
  };

  return (
    <div className="relative w-full flex flex-col space-y-7 pb-24 select-none">
      {/* Top Welcome Bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-full border border-[#D4AF37]/35 p-0.5 shrink-0">
            <div className="w-full h-full bg-gradient-to-br from-stone-800 to-stone-950 rounded-full flex items-center justify-center overflow-hidden">
              <span className="text-[10px] font-bold text-[#D4AF37] tracking-wider uppercase">
                {progress.name ? progress.name.substring(0, 2).toUpperCase() : 'IA'}
              </span>
            </div>
          </div>
          <div className="space-y-0.5">
            <p className="font-mono text-[9px] uppercase tracking-[0.2em] text-[#D4AF37]/75 font-semibold">
              {getGreeting()}
            </p>
            <h2 className="font-serif text-xl font-medium text-white">
              {progress.name || 'Seeker'}
            </h2>
          </div>
        </div>

        {/* Ambient audio toggle (high product feel larping but functional click) */}
        <button
          id="btn-ambient-sound"
          onClick={() => setAmbientSound(!ambientSound)}
          className={`w-9 h-9 rounded-full border flex items-center justify-center transition-all ${
            ambientSound 
              ? 'bg-[#D4AF37]/15 border-[#D4AF37]/45 text-[#D4AF37] shadow-[0_0_12px_rgba(212,175,55,0.25)]'
              : 'bg-white/5 border-white/10 text-stone-400'
          }`}
          title={ambientSound ? "Mute Zen Focus sound" : "Play Zen Focus sound"}
        >
          {ambientSound ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
        </button>
      </div>

      {/* Wellness Dashboard Stats block with Julianne Daily Goal Progress info built in */}
      <div className="grid grid-cols-1 gap-4">
        <div className="grid grid-cols-2 gap-3.5">
          <div 
            id="stat-box-streak"
            onClick={() => onChangeTab('streak')}
            className="glass-panel p-4.5 rounded-[28px] cursor-pointer hover:border-[#D4AF37]/30 transition-all flex flex-col justify-between h-24 group relative overflow-hidden"
          >
            {/* Subtle background flash */}
            <div className="absolute right-[-10px] top-[-10px] w-12 h-12 bg-[#D4AF37]/5 rounded-full blur-xl group-hover:bg-[#D4AF37]/10 transition-colors" />
            <div className="flex items-center justify-between">
              <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-gray-550 font-semibold group-hover:text-[#D4AF37] transition-colors">Streak Count</span>
              <Flame className="h-4 w-4 text-[#D4AF37] fill-[#D4AF37]/10" />
            </div>
            <div>
              <span className="font-display text-2xl font-semibold text-white">{progress.streakCount}</span>
              <span className="font-sans text-[10px] text-gray-400 font-light ml-1.5">days active</span>
            </div>
          </div>

          <div 
            id="stat-box-saved"
            onClick={() => onChangeTab('saved')}
            className="glass-panel p-4.5 rounded-[28px] cursor-pointer hover:border-[#D4AF37]/30 transition-all flex flex-col justify-between h-24 group relative overflow-hidden"
          >
            <div className="absolute right-[-10px] top-[-10px] w-12 h-12 bg-rose-500/5 rounded-full blur-xl group-hover:bg-rose-500/10 transition-colors" />
            <div className="flex items-center justify-between">
              <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-gray-550 font-semibold group-hover:text-rose-450 transition-colors">My Deck</span>
              <Heart className="h-4 w-4 text-rose-550 fill-rose-550/10" />
            </div>
            <div>
              <span className="font-display text-2xl font-semibold text-white">{progress.favorites.length}</span>
              <span className="font-sans text-[10px] text-gray-400 font-light ml-1.5">saved</span>
            </div>
          </div>
        </div>

        {/* Sophisticated Dark Daily Goal progress card */}
        <div className="glass-panel p-5 rounded-[28px] space-y-3.5">
          <div className="flex justify-between items-center">
            <span className="text-[10px] font-mono tracking-wider text-gray-450 uppercase font-semibold">DAILY CONNECTION OBJECTIVE</span>
            <span className="text-[#D4AF37] font-display font-semibold text-xs tracking-wider bg-[#D4AF37]/10 px-2 py-0.5 rounded-md">85% ALIGNED</span>
          </div>
          <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
            <div className="w-[85%] h-full bg-gradient-to-r from-orange-450 to-[#D4AF37]"></div>
          </div>
          <div className="flex justify-between items-center text-[10px] font-sans text-gray-450">
            <span className="italic">2 more affirmations to perfect your baseline today</span>
            <span className="font-mono text-[#D4AF37]">LEVEL 3</span>
          </div>
        </div>
      </div>

      {/* TODAY'S AFFIRMATION HERO SECTOR */}
      <div className="space-y-3.5">
        <div className="flex items-center justify-between">
          <span className="font-display text-xs tracking-wider text-stone-400 font-medium font-semibold uppercase">Daily Intention</span>
          <span className="font-mono text-[9px] tracking-widest text-[#d4af37] font-bold">STABLE FOR 24H</span>
        </div>

        <motion.div
          id="hero-daily-affirmation"
          whileHover={{ y: -2 }}
          transition={{ duration: 0.3 }}
          onClick={() => onOpenImmersive(affirmationOfTheDay)}
          className="relative rounded-[32px] border border-stone-850/60 p-6 flex flex-col justify-between h-[230px] overflow-hidden cursor-pointer shadow-[0_20px_45px_-12px_rgba(0,0,0,0.7)] group"
        >
          {/* Obsidian dark custom palette */}
          <div 
            className="absolute inset-0 z-0 opacity-100"
            style={{
              background: `linear-gradient(135deg, ${affirmationOfTheDay.gradientFrom} 0%, #030303 60%, ${affirmationOfTheDay.gradientTo} 100%)`
            }}
          />
          <div className="absolute inset-0 z-0 bg-stone-900/5 group-hover:opacity-10 transition-opacity" />
          
          {/* Subtle lighting gold dot */}
          <div className="absolute right-8 top-12 w-28 h-28 rounded-full blur-2xl opacity-20 bg-amber-400" />

          {/* Top category indicator */}
          <div className="relative z-10 flex justify-between items-center w-full">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              <span className="font-mono text-[9px] text-stone-400 uppercase tracking-widest font-semibold">{affirmationOfTheDay.category}</span>
            </div>
            <span className="font-mono text-[9px] text-amber-500/80 tracking-widest uppercase bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 font-bold">Affirmation of the Day</span>
          </div>

          {/* Main content */}
          <div className="relative z-10 my-auto text-left py-1">
            <p className="font-serif text-lg leading-relaxed text-stone-100 group-hover:text-stone-50 italic">
              "{affirmationOfTheDay.text}"
            </p>
          </div>

          {/* Prompt interactive bar */}
          <div className="relative z-10 flex justify-between items-center w-full pt-1">
            <p className="font-sans text-[11px] text-stone-400 font-light">By {affirmationOfTheDay.author || 'Daily Alignment'}</p>
            <div className="flex items-center space-x-1.5 font-display text-[10px] text-amber-400 font-medium tracking-wider uppercase group-hover:translate-x-1 transition-transform">
              <span>Initiate</span>
              <ArrowRight className="h-3 w-3" />
            </div>
          </div>
        </motion.div>
      </div>

      {/* CATEGORY SELECTOR CHIPS GRID */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="font-display text-xs tracking-wider text-stone-400 font-semibold uppercase">Focus Fields</span>
          <button 
            id="btn-explore-all"
            onClick={() => onChangeTab('explore')}
            className="font-display text-[11px] text-stone-500 hover:text-amber-400 flex items-center space-x-1 transition-colors"
          >
            <span>All Anchors</span>
            <ChevronRight className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {CATEGORIES_MAPPING.map((cat, idx) => {
            const Icon = cat.icon;
            return (
              <motion.button
                id={`btn-mood-anchor-${cat.id}`}
                key={cat.id}
                onClick={() => handleCategoryClick(cat.id)}
                whileTap={{ scale: 0.98 }}
                className="glass-panel flex items-center p-3.5 rounded-[22px] text-left border border-stone-900 bg-stone-950/40 hover:bg-stone-950 hover:border-stone-850 transition-all duration-300 group"
              >
                <div className={`w-9 h-9 rounded-[16px] flex items-center justify-center mr-3 ${cat.bg}`}>
                  <Icon className={`h-4.5 w-4.5 ${cat.color}`} />
                </div>
                <div className="space-y-0.5">
                  <span className="font-display text-xs text-stone-250 font-semibold tracking-wide transition-colors group-hover:text-stone-100">
                    {cat.label}
                  </span>
                  <p className="font-mono text-[8px] text-stone-550 font-light tracking-wide uppercase">Practice Path</p>
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Inspirational Quote / Micro banner */}
      <div className="glass-panel p-4 rounded-[26px] bg-gradient-to-r from-stone-950 to-neutral-900 border border-stone-850/40 flex items-start space-x-3.5">
        <div className="mt-1 w-2.5 h-2.5 rounded-full bg-amber-400 shrink-0" />
        <div className="space-y-1">
          <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-[#d4af37] font-semibold">Universal Lore</span>
          <p className="font-sans text-[11px] text-stone-400 leading-normal font-light">
            “Your mind is a grand transmitter. Tuning your internal radio to certainty is the highest act of biological sovereignty.”
          </p>
        </div>
      </div>
    </div>
  );
}
