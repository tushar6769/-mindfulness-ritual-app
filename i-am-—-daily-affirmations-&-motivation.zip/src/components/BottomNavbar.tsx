/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Home, Compass, Heart, Flame } from 'lucide-react';
import { motion } from 'motion/react';
import { TabType } from '../types';

interface BottomNavbarProps {
  activeTab: TabType;
  onChangeTab: (tab: TabType) => void;
  favoritesCount: number;
  streakCount: number;
}

export default function BottomNavbar({ activeTab, onChangeTab, favoritesCount, streakCount }: BottomNavbarProps) {
  const tabs = [
    { id: 'home' as TabType, label: 'I Am', icon: Home },
    { id: 'explore' as TabType, label: 'Explore', icon: Compass },
    { id: 'saved' as TabType, label: 'Library', icon: Heart, badge: favoritesCount > 0 ? favoritesCount : undefined },
    { id: 'streak' as TabType, label: 'Streak', icon: Flame, badge: streakCount > 0 ? streakCount : undefined, badgeStyle: 'bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/35 font-display' }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 h-[84px] bg-gradient-to-t from-black via-black/95 to-transparent px-4 pb-5 pt-2 select-none">
      <div className="mx-auto flex h-14 max-w-md items-center justify-around rounded-[28px] border border-white/10 bg-black/85 px-3 shadow-2xl backdrop-blur-xl">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              id={`nav-item-${tab.id}`}
              key={tab.id}
              onClick={() => onChangeTab(tab.id)}
              className="relative flex flex-col items-center justify-center py-1 transition-all focus:outline-none w-1/4"
              role="tab"
              aria-selected={isActive}
            >
              <div className="relative p-1">
                <Icon
                  id={`nav-icon-${tab.id}`}
                  className={`h-5 w-5 transition-all duration-300 ${
                    isActive ? 'text-[#D4AF37] scale-110 drop-shadow-[0_0_8px_rgba(212,175,55,0.55)]' : 'text-stone-500 hover:text-stone-300'
                  }`}
                />
                
                {tab.badge !== undefined && (
                  <span className={`absolute -right-2.5 -top-1 px-1.5 py-0.5 rounded-full text-[10px] font-bold ${tab.badgeStyle || 'bg-[#D4AF37] text-black'} flex h-4 min-w-4 items-center justify-center`}>
                    {tab.badge}
                  </span>
                )}
              </div>

              <span
                className={`mt-1 font-display text-[10px] tracking-widest uppercase font-medium transition-colors duration-300 ${
                  isActive ? 'text-white font-semibold' : 'text-stone-600'
                }`}
              >
                {tab.label}
              </span>

              {isActive && (
                <motion.div
                  layoutId="activeTabIndicator"
                  className="absolute bottom-[-6px] h-[3px] w-5 rounded-full bg-[#D4AF37]"
                  transition={{ type: 'spring', stiffness: 350, damping: 25 }}
                />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
