/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, ArrowRight, User } from 'lucide-react';

interface OnboardingProps {
  onComplete: (name: string, preferredCategory: string) => void;
}

const CATEGORIES_INFO = [
  { id: 'all', label: 'All Affirmations', desc: 'A balance of wisdom across all aspects' },
  { id: 'self-love', label: 'Self Love & Respect', desc: 'Silence self-doubt & embrace inner peace' },
  { id: 'confidence', label: 'Confidence & Power', desc: 'Step as your authentic supreme self' },
  { id: 'success', label: 'Success & Legacy', desc: 'Attract mastercraft opportunities & wealth' },
  { id: 'discipline', label: 'Discipline & Focus', desc: 'Align your actions with clear intent' },
  { id: 'fitness', label: 'Fitness & Longevity', desc: 'Honor and power your physical engine' },
  { id: 'gratitude', label: 'Gratitude & Abundance', desc: 'Be rich in the present, appreciative' },
  { id: 'health', label: 'Teal Health & Vitality', desc: 'Conscious restoration of neural system' },
  { id: 'study', label: 'Intellect & Absorption', desc: 'Digest complex wisdom systematically' },
];

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const handleNextStep = () => {
    if (step === 1 && name.trim()) {
      setStep(2);
    } else if (step === 2) {
      onComplete(name.trim(), selectedCategory);
    }
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col justify-between bg-[#030303] text-stone-100 overflow-hidden px-6 pt-16 pb-12 select-none select-none">
      {/* Background Cinematic Glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] h-[350px] bg-gradient-to-r from-amber-500/10 via-amber-900/10 to-transparent rounded-full blur-[80px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-[10%] w-[300px] h-[300px] bg-gradient-to-r from-yellow-600/5 via-stone-900 to-transparent rounded-full blur-[100px] pointer-events-none" />

      {/* Brand Header */}
      <div className="z-10 flex flex-col items-center">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: 'easeOut' }}
          className="flex flex-col items-center"
        >
          <div className="w-12 h-12 rounded-[18px] border border-amber-500/30 bg-stone-950/80 flex items-center justify-center shadow-[0_0_15px_rgba(212,175,55,0.15)] mb-3">
            <Sparkles className="h-5 w-5 text-amber-400" />
          </div>
          <span className="font-display text-[11px] tracking-[0.25em] text-amber-400 font-semibold uppercase">Mindfulness Ritual</span>
          <h1 className="font-serif text-3xl font-medium text-stone-100 mt-1">I Am</h1>
        </motion.div>
      </div>

      {/* Main Form Fields */}
      <div className="z-10 my-auto w-full max-w-sm mx-auto">
        <AnimatePresence mode="wait">
          {step === 1 ? (
            <motion.div
              key="step-name"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.6, ease: 'easeInOut' }}
              className="flex flex-col space-y-7"
            >
              <div className="text-center space-y-2">
                <span className="font-mono text-[10px] text-amber-500/60 uppercase tracking-widest block font-bold">Introduction</span>
                <h2 className="font-serif text-2xl text-stone-200">What should we call you?</h2>
                <p className="text-xs text-stone-400 leading-relaxed max-w-[280px] mx-auto">
                  Your daily rituals will use this name to personalize your path of alignment.
                </p>
              </div>

              <div className="relative">
                <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
                  <User className="h-4 w-4 text-amber-400/40" />
                </div>
                <input
                  id="user-name-input"
                  type="text"
                  placeholder="Your name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full h-14 pl-12 pr-4 rounded-full border border-stone-800 bg-stone-950/80 text-stone-100 placeholder-stone-600 font-display tracking-wide focus:outline-none focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/30 transition-all text-center placeholder:text-center placeholder:pl-0"
                  maxLength={18}
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && name.trim()) handleNextStep();
                  }}
                />
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="step-category"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.6, ease: 'easeInOut' }}
              className="flex flex-col space-y-6"
            >
              <div className="text-center space-y-1">
                <span className="font-mono text-[10px] text-amber-500/60 uppercase tracking-widest block font-bold">Focus Path</span>
                <h2 className="font-serif text-2xl text-stone-200">Choose your anchor</h2>
                <p className="text-xs text-stone-400 leading-relaxed">
                  Select your primary focus area to begin your daily practice.
                </p>
              </div>

              <div className="grid grid-cols-1 gap-2 max-h-[380px] overflow-y-auto pr-1">
                {CATEGORIES_INFO.map((cat) => {
                  const isSelected = selectedCategory === cat.id;
                  return (
                    <button
                      id={`onboarding-cat-${cat.id}`}
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`w-full flex items-center justify-between p-3.5 rounded-[22px] text-left border transition-all duration-300 ${
                        isSelected
                          ? 'bg-gradient-to-r from-stone-900 to-amber-950/30 border-amber-500/40 glow-selected shadow-amber-500/5'
                          : 'bg-stone-950/60 border-stone-900/60 hover:bg-stone-900/30'
                      }`}
                    >
                      <div className="space-y-0.5">
                        <span className={`font-display text-xs font-semibold tracking-wide ${isSelected ? 'text-amber-400' : 'text-stone-300'}`}>
                          {cat.label}
                        </span>
                        <p className="text-[10px] text-stone-500 font-light leading-snug">{cat.desc}</p>
                      </div>
                      {isSelected && (
                        <div className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-[0_0_8px_rgba(245,158,11,0.8)]" />
                      )}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* CTA Footer Row */}
      <div className="z-10 flex flex-col items-center mt-8">
        <motion.button
          id="onboarding-next-btn"
          whileTap={{ scale: 0.96 }}
          onClick={handleNextStep}
          disabled={step === 1 && !name.trim()}
          className={`flex h-14 w-full max-w-xs items-center justify-between rounded-full px-6 font-display text-xs tracking-[0.15em] font-semibold uppercase shadow-xl transition-all duration-500 ${
            (step === 1 && !name.trim())
              ? 'bg-stone-900/40 border border-stone-950 text-stone-600 cursor-not-allowed'
              : 'border border-amber-500/20 bg-gradient-to-r from-amber-500 to-yellow-600 text-stone-950 shadow-amber-500/10 cursor-pointer hover:shadow-[0_0_20px_rgba(245,158,11,0.2)]'
          }`}
        >
          <span className="pl-4">{step === 1 ? 'Select Focus Path' : 'Initiate Practice'}</span>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
            (step === 1 && !name.trim()) ? 'bg-stone-950/20' : 'bg-stone-950/15'
          }`}>
            <ArrowRight className="h-4 w-4" />
          </div>
        </motion.button>

        <p className="font-mono text-[9px] text-stone-600 mt-5 uppercase tracking-widest text-center select-none font-medium">
          Purely private. Data persists on your secure local device.
        </p>
      </div>
    </div>
  );
}
