/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence, useMotionValue, useTransform } from 'motion/react';
import { Heart, Quote, ChevronLeft, ChevronRight, Copy, Check, Type } from 'lucide-react';
import { Affirmation } from '../types';

interface CardSwiperProps {
  affirmations: Affirmation[];
  favorites: string[];
  onToggleFavorite: (id: string) => void;
  fontStyle: 'serif' | 'display' | 'sans';
  onChangeFontStyle: (style: 'serif' | 'display' | 'sans') => void;
}

export default function CardSwiper({
  affirmations,
  favorites,
  onToggleFavorite,
  fontStyle,
  onChangeFontStyle
}: CardSwiperProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [copied, setCopied] = useState(false);

  // If there are no affirmations, display placeholder state
  if (affirmations.length === 0) {
    return (
      <div className="flex h-[450px] flex-col items-center justify-center text-center p-6 bg-stone-950/40 rounded-[32px] border border-stone-900">
        <p className="font-serif text-lg text-stone-400">Your journal is serene.</p>
        <p className="text-xs text-stone-600 mt-1 max-w-[200px]">Choose another focus path to load affirmations.</p>
      </div>
    );
  }

  const currentAffirmation = affirmations[currentIndex % affirmations.length];
  const isFavorite = favorites.includes(currentAffirmation.id);

  // Framer motion drag setup
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-150, 0, 150], [-6, 0, 6]);
  const opacity = useTransform(x, [-150, -80, 0, 80, 150], [0.5, 0.9, 1, 0.9, 0.5]);

  const handleDragEnd = (_event: any, info: any) => {
    const sweep = info.offset.x;
    const threshold = 80;

    if (sweep < -threshold) {
      // swipe left -> next
      handleNext();
    } else if (sweep > threshold) {
      // swipe right -> prev
      handlePrev();
    }
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % affirmations.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + affirmations.length) % affirmations.length);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(`"${currentAffirmation.text}" — ${currentAffirmation.author || 'Daily Ritual'}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Font styles map
  const fontClasses = {
    serif: 'font-serif text-3xl font-normal leading-relaxed md:leading-relaxed text-white',
    display: 'font-display text-2xl font-medium tracking-wide leading-snug text-white',
    sans: 'font-sans text-xl font-normal tracking-wide leading-relaxed text-gray-100'
  };

  const fontName = {
    serif: 'Classic Serif',
    display: 'Space Display',
    sans: 'Clean Sans'
  };

  const toggleFont = () => {
    const styles: Array<'serif' | 'display' | 'sans'> = ['serif', 'display', 'sans'];
    const nextIdx = (styles.indexOf(fontStyle) + 1) % styles.length;
    onChangeFontStyle(styles[nextIdx]);
  };

  return (
    <div className="relative w-full max-w-sm mx-auto select-none mt-1 select-none">
      {/* Floating Animated Gradient Orb matched to card glow */}
      <div 
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 rounded-full blur-[80px] pointer-events-none transition-all duration-1000 ease-in-out z-0 opacity-40 bg-[#D4AF37]/10"
      />

      {/* Control overlay headers: Category and Custom Font switcher */}
      <div className="flex items-center justify-between px-3 mb-6 relative z-10 select-none">
        <span className="font-mono text-[9px] text-[#D4AF37] tracking-[0.2em] font-semibold uppercase bg-[#D4AF37]/10 px-3 py-1 rounded-full border border-[#D4AF37]/15">
          {currentAffirmation.category.replace('-', ' ')}
        </span>
        
        <button
          id="btn-switch-typography"
          onClick={toggleFont}
          className="flex items-center space-x-1.5 font-display text-[9px] text-gray-400 tracking-wider hover:text-[#D4AF37] px-2.5 py-1 rounded-full bg-white/5 border border-white/8 transition-colors"
          title="Switch Style Font"
        >
          <Type className="h-3 w-3 text-[#D4AF37]" />
          <span>{fontName[fontStyle]}</span>
        </button>
      </div>

      {/* Swipe Deck Stage */}
      <div className="relative h-[430px] w-full flex items-center justify-center z-10 p-2">
        <AnimatePresence mode="popLayout">
          <motion.div
            id={`card-${currentAffirmation.id}`}
            key={currentAffirmation.id}
            style={{ x, rotate, opacity }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={0.7}
            onDragEnd={handleDragEnd}
            whileDrag={{ scale: 0.98, cursor: 'grabbing' }}
            initial={{ opacity: 0, scale: 0.94, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: -15 }}
            transition={{ type: 'spring', stiffness: 300, damping: 24 }}
            className="absolute w-full h-full rounded-[40px] p-7 flex flex-col justify-between shadow-[0_30px_70px_-15px_rgba(0,0,0,0.9)] border border-white/10 overflow-hidden group cursor-grab glass-panel"
          >
            {/* Elegant luxury Sophisticated Dark base inside card */}
            <div 
              className="absolute inset-0 z-0 opacity-95"
              style={{
                background: `linear-gradient(135deg, ${currentAffirmation.gradientFrom} 0%, #0c0c0c 70%, ${currentAffirmation.gradientTo} 100%)`
              }}
            />
            {/* Delicate inner border highlights */}
            <div className="absolute inset-0 z-0 bg-gradient-to-b from-white/5 via-transparent to-transparent pointer-events-none" />

            {/* Custom Interactive Floating Accent */}
            <div 
              className="absolute -right-20 -top-20 w-44 h-44 rounded-full blur-3xl z-0 transition-all duration-700 pointer-events-none opacity-40"
              style={{ backgroundColor: currentAffirmation.glowColor }}
            />

            {/* Card contents - Title quote icon */}
            <div className="relative z-10 flex w-full top-1 justify-between items-center">
              <div className="w-9 h-9 rounded-full bg-white/5 flex items-center justify-center border border-white/10">
                <Quote className="h-4 w-4 text-[#D4AF37]" />
              </div>
              <span className="font-mono text-[9px] tracking-widest text-gray-500 font-bold">SWIPE</span>
            </div>

            {/* Core Text Body */}
            <div className="relative z-10 px-1 py-4 my-auto select-none">
              <span className={fontClasses[fontStyle]}>
                {currentAffirmation.text}
              </span>
            </div>

            {/* Card bottom - Author, Share, Fav buttons */}
            <div className="relative z-10 flex w-full justify-between items-center pt-2">
              <div className="text-left">
                <p className="font-mono text-[9px] uppercase tracking-[0.2em] text-[#D4AF37]/70 font-semibold">Author</p>
                <p className="font-sans text-xs text-gray-300 font-medium tracking-wide mt-0.5">{currentAffirmation.author || 'Eternal Mind'}</p>
              </div>

              {/* Action Circle Row */}
              <div className="flex items-center space-x-2">
                <button
                  id={`btn-copy-${currentAffirmation.id}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    handleCopy();
                  }}
                  className={`w-10 h-10 rounded-full flex items-center justify-center border transition-all duration-300 ${
                    copied
                      ? 'bg-[#D4AF37]/15 border-[#D4AF37]/40 text-[#D4AF37] font-semibold'
                      : 'bg-white/5 border-white/10 hover:border-white/20 text-stone-400 hover:text-white'
                  }`}
                  aria-label="Copy Affirmation"
                  title="Copy Affirmation"
                >
                  {copied ? (
                    <Check className="h-4 w-4 drop-shadow-[0_0_4px_rgba(212,175,55,0.4)]" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </button>

                <button
                  id={`btn-fav-${currentAffirmation.id}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleFavorite(currentAffirmation.id);
                  }}
                  className={`w-10 h-10 rounded-full flex items-center justify-center border transition-all duration-300 ${
                    isFavorite
                      ? 'bg-[#D4AF37] text-black border-[#D4AF37]/80 shadow-[0_0_15px_rgba(212,175,55,0.4)]'
                      : 'bg-white/5 border-white/10 hover:border-white/20 text-stone-400 hover:text-white'
                  }`}
                  aria-label="Favorite Affirmation"
                  title="Favorite Affirmation"
                >
                  <Heart
                    className={`h-4 w-4 transition-transform duration-300 ${
                      isFavorite ? 'fill-current scale-110' : 'hover:scale-105'
                    }`}
                  />
                </button>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Navigation Helper Buttons for Desktop Compatibility */}
      <div className="flex items-center justify-center space-x-12 mt-4 relative z-10 font-sans">
        <button
          id="btn-swiper-prev"
          onClick={handlePrev}
          className="w-11 h-11 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-gray-450 hover:text-[#D4AF37] hover:border-[#D4AF37]/30 hover:bg-white/10 active:scale-95 transition-all shadow-md"
          title="Previous Affirmation"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>

        <span className="font-mono text-[10px] text-gray-500 tracking-wider font-semibold">
          {((currentIndex % affirmations.length) + 1).toString().padStart(2, '0')} / {affirmations.length.toString().padStart(2, '0')}
        </span>

        <button
          id="btn-swiper-next"
          onClick={handleNext}
          className="w-11 h-11 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-gray-450 hover:text-[#D4AF37] hover:border-[#D4AF37]/30 hover:bg-white/10 active:scale-95 transition-all shadow-md"
          title="Next Affirmation"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
}
