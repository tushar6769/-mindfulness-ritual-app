/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Flame, Medal, Calendar, Check, AlertCircle, ArrowLeftRight, Sparkles } from 'lucide-react';
import { UserProgress } from '../types';
import { getLocalDateString, getMilestoneForStreak, MILESTONES } from '../data';

interface StreakScreenProps {
  progress: UserProgress;
  onRecordCheckIn: () => void;
}

export default function StreakScreen({ progress, onRecordCheckIn }: StreakScreenProps) {
  const [celebrate, setCelebrate] = useState(false);
  
  const todayStr = getLocalDateString();
  const alreadyCheckedInToday = progress.readHistory.includes(todayStr);

  const activeMilestone = getMilestoneForStreak(progress.streakCount);

  // Compute the last 14 dates to render inside our calendar-style visualization
  const lastFortnightDates = Array.from({ length: 14 }, (_, idx) => {
    const d = new Date();
    d.setDate(d.getDate() - (13 - idx)); // Ordered from oldest to newest (today)
    return getLocalDateString(d);
  });

  const handleCheckInClick = () => {
    if (!alreadyCheckedInToday) {
      onRecordCheckIn();
      setCelebrate(true);
      setTimeout(() => setCelebrate(false), 2500);
    }
  };

  return (
    <div className="relative w-full flex flex-col space-y-6 pb-24 select-none">
      {/* Title */}
      <div className="space-y-1">
        <span className="font-mono text-[9px] uppercase tracking-[0.25em] text-[#D4AF37]/75 font-semibold">Habit Tracker</span>
        <h2 className="font-serif text-2xl font-normal text-white">Ritual Frequency</h2>
      </div>

      {/* Main Large Metric Display Ring & CTA Button */}
      <div className="glass-panel p-6 rounded-[32px] bg-white/4 border border-white/10 relative flex flex-col items-center justify-center text-center overflow-hidden">
        {/* Cinematic glow background */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-[#D4AF37]/8 rounded-full blur-3xl pointer-events-none" />

        <div className="relative flex items-center justify-center h-32 w-32 mb-4">
          {/* Circular dial outline */}
          <div className="absolute inset-0 rounded-full border border-stone-900 border-[#D4AF37]/35 animate-spin" style={{ animationDuration: '8s' }} />
          <div className="absolute inset-2 rounded-full border border-white/5" />
          
          <div className="flex flex-col items-center justify-center relative z-10">
            <Flame className="h-7 w-7 text-[#D4AF37] drop-shadow-[0_0_8px_rgba(212,175,55,0.6)]" />
            <span className="font-display text-4xl font-extrabold text-white tracking-tight mt-1">{progress.streakCount}</span>
            <span className="font-mono text-[8px] uppercase tracking-wider text-gray-500 font-bold">DAYS ACTIVE</span>
          </div>
        </div>

        {/* Dynamic checking message */}
        <div className="space-y-1.5 mb-5 max-w-[260px]">
          <h3 className="font-display text-sm font-semibold text-stone-150">
            {alreadyCheckedInToday ? "Subconscious Locked" : "Seal Today's Frequency"}
          </h3>
          <p className="text-[11px] text-gray-400 leading-normal font-light">
            {alreadyCheckedInToday 
              ? "Your baseline sequence is secured. Re-attending to affirmations cements connection."
              : "Gaze upon an affirmation and commit 1 minute of still attention to lock alignment now."}
          </p>
        </div>

        <button
          id="btn-streak-checkin"
          onClick={handleCheckInClick}
          disabled={alreadyCheckedInToday}
          className={`relative h-13 w-full max-w-xs rounded-full flex items-center justify-center space-x-2 font-display text-xs font-semibold tracking-widest uppercase transition-all duration-500 ${
            alreadyCheckedInToday
              ? 'bg-white/5 border border-white/10 text-stone-500 cursor-default'
              : 'border-none bg-[#D4AF37] text-black hover:bg-opacity-90 shadow-[0_0_20px_rgba(212,175,55,0.4)] cursor-pointer hover:shadow-[0_0_30px_rgba(212,175,55,0.55)]'
          }`}
        >
          {alreadyCheckedInToday ? (
            <>
              <Check className="h-4.5 w-4.5" />
              <span>Today Logged</span>
            </>
          ) : (
            <>
              <Sparkles className="h-4 w-4 animate-spin-slow" />
              <span>Log alignment Check-in</span>
            </>
          )}

          {/* Celebratory particles effect */}
          <AnimatePresence>
            {celebrate && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1.15 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-[#D4AF37]/20 rounded-full blur-xl pointer-events-none"
              />
            )}
          </AnimatePresence>
        </button>
      </div>

      {/* CALENDAR VIEW GRID: LAST 14 DAYS OF RITUAL */}
      <div className="space-y-3.5">
        <div className="flex items-center justify-between text-xs font-display text-gray-400 font-semibold uppercase">
          <span>Continuous Grid</span>
          <span className="font-mono text-[9px] text-[#D4AF37] tracking-wider uppercase font-bold font-sans">14 day interval</span>
        </div>

        <div className="glass-panel p-4.5 rounded-[26px] bg-white/4 border border-white/10">
          <div className="grid grid-cols-7 gap-2.5">
            {lastFortnightDates.map((itemDate, idx) => {
              const matched = progress.readHistory.includes(itemDate);
              const isToday = itemDate === todayStr;
              
              // Formatting for mini date
              const dateObj = new Date(itemDate);
              const dayStr = String(dateObj.getDate());
              const monthShort = dateObj.toLocaleDateString('en-US', { month: 'short' }).substring(0, 3);

              return (
                <div
                  id={`calendar-cell-${itemDate}`}
                  key={itemDate}
                  className="flex flex-col items-center justify-center p-1.5 rounded-[14px] border border-white/5 bg-white/2"
                >
                  <span className="font-mono text-[7px] text-gray-500 uppercase tracking-tight block">
                    {monthShort}
                  </span>
                  <span className="font-display text-xs font-semibold text-stone-300 mt-0.5 mb-1.5 block">
                    {dayStr}
                  </span>

                  <div
                    id={`calendar-dot-${itemDate}`}
                    className={`w-5.5 h-5.5 rounded-full flex items-center justify-center transition-all ${
                      matched
                        ? 'bg-[#D4AF37] text-black shadow-[0_0_8px_rgba(212,175,55,0.45)] font-bold'
                        : isToday
                        ? 'border border-dashed border-[#D4AF37]/50 text-[#D4AF37]'
                        : 'bg-white/5 text-stone-500'
                    }`}
                  >
                    {matched ? (
                      <Check className="h-3 w-3 stroke-[3]" />
                    ) : (
                      <span className="text-[9px] font-bold">•</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          
          <div className="flex items-center space-x-2 mt-4 pt-4 border-t border-white/10">
            <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />
            <p className="font-mono text-[9px] text-stone-550 tracking-wide uppercase">
              Highlight represents a validated connection interval on that cycle.
            </p>
          </div>
        </div>
      </div>

      {/* MILESTONES / BADGES SCROLL */}
      <div className="space-y-3.5">
        <div className="flex items-center justify-between">
          <span className="font-display text-xs tracking-wider text-gray-400 font-semibold uppercase">Habit Milestones</span>
          <span className="font-mono text-[9px] text-[#D4AF37] font-bold">LIFETIME</span>
        </div>

        <div className="space-y-2.5">
          {MILESTONES.map((mile) => {
            const unlocked = progress.streakCount >= mile.days;
            return (
              <div
                id={`milestone-${mile.days}`}
                key={mile.days}
                className={`glass-panel p-4 rounded-[22px] border transition-all duration-300 flex items-center justify-between relative overflow-hidden ${
                  unlocked
                    ? 'bg-white/4 border-[#D4AF37]/25 text-white'
                    : 'bg-white/2 border-white/5 text-[#E5E5E5]/45'
                }`}
              >
                <div className="flex items-center space-x-3.5 relative z-10 w-4/5">
                  <div className={`w-10 h-10 rounded-[14px] flex items-center justify-center shrink-0 border ${
                    unlocked
                      ? 'bg-[#D4AF37]/10 border-[#D4AF37]/30 text-[#D4AF37] shadow-[0_0_10px_rgba(212,175,55,0.2)]'
                      : 'bg-white/5 border-white/10 text-stone-600'
                  }`}>
                    <Medal className="h-5 w-5" />
                  </div>
                  <div className="space-y-0.5">
                    <span className={`font-display text-xs font-semibold ${unlocked ? 'text-white' : 'text-stone-500 font-medium'}`}>
                      {mile.label} <span className="font-sans text-[10px] font-normal text-stone-400">({mile.days}d)</span>
                    </span>
                    <p className={`text-[10px] leading-relaxed font-light ${unlocked ? 'text-stone-300' : 'text-stone-600'}`}>
                      {mile.message}
                    </p>
                  </div>
                </div>

                <div className="relative z-10 flex flex-col items-end shrink-0 font-sans">
                  {unlocked ? (
                    <span className="font-mono text-[8px] text-[#D4AF37] uppercase tracking-widest bg-[#D4AF37]/10 px-2 py-0.5 rounded border border-[#D4AF37]/20 font-bold">UNLOCKED</span>
                  ) : (
                    <span className="font-mono text-[8px] text-stone-500 uppercase tracking-widest bg-white/5 px-2 py-0.5 rounded border border-white/5">LOCKED</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
