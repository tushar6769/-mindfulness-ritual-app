/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Trash2, ArrowRight, Quote, Sparkles, Sliders, ChevronLeft } from 'lucide-react';
import { Affirmation, UserProgress } from '../types';
import { AFFIRMATIONS } from '../data';
import CardSwiper from './CardSwiper';

interface SavedScreenProps {
  progress: UserProgress;
  onToggleFavorite: (id: string) => void;
  fontStyle: 'serif' | 'display' | 'sans';
  onChangeFontStyle: (style: 'serif' | 'display' | 'sans') => void;
  onChangeTab: (tab: 'home' | 'explore' | 'saved' | 'streak') => void;
}

export default function SavedScreen({
  progress,
  onToggleFavorite,
  fontStyle,
  onChangeFontStyle,
  onChangeTab
}: SavedScreenProps) {
  const [activePlayDeck, setActivePlayDeck] = useState<boolean>(false);

  // Retrieve favorited elements
  const savedItems = AFFIRMATIONS.filter(item => progress.favorites.includes(item.id));

  // Handle empty states gracefully
  if (savedItems.length === 0) {
    return (
      <div className="relative min-h-[500px] w-full flex flex-col items-center justify-center text-center px-4 select-none">
        <div className="w-16 h-16 rounded-full border border-white/10 bg-white/5 flex items-center justify-center shadow-lg mb-4 text-[#D4AF37]">
          <Heart className="h-6 w-6 stroke-[1.5]" />
        </div>
        <h3 className="font-serif text-xl font-normal text-[#D4AF37]">The library is serene</h3>
        <p className="text-xs text-stone-500 leading-relaxed max-w-[250px] mx-auto mt-1.5">
          Begin capturing personal anchors to compose your custom meditation deck.
        </p>

        <button
          id="btn-saved-go-explore"
          onClick={() => onChangeTab('explore')}
          className="mt-6 flex h-11 items-center justify-center space-x-2 rounded-full border border-[#D4AF37]/20 bg-[#D4AF37]/10 px-5 font-display text-[11px] font-semibold tracking-widest uppercase text-[#D4AF37] hover:bg-[#D4AF37] hover:text-black transition-all duration-300 shadow-md focus:outline-none"
        >
          <span>Explore Anchors</span>
          <ArrowRight className="h-4.5 w-4.5" />
        </button>
      </div>
    );
  }

  return (
    <div className="relative w-full flex flex-col space-y-6 pb-24 select-none">
      <AnimatePresence mode="wait">
        {!activePlayDeck ? (
          <motion.div
            key="saved-list"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6"
          >
            {/* Header info */}
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <span className="font-mono text-[9px] uppercase tracking-[0.25em] text-[#D4AF37]/75 font-semibold">Saved Library</span>
                <h2 className="font-serif text-2xl font-normal text-white">Mindfulness Deck</h2>
              </div>

              {/* Enter Swipe mode button */}
              <button
                id="btn-start-swiper-saved"
                onClick={() => setActivePlayDeck(true)}
                className="flex items-center space-x-1.5 font-display text-[10px] tracking-wider text-black bg-[#D4AF37] px-3.5 py-1.5 rounded-full hover:bg-[opacity-90] transition-all shadow-md font-semibold uppercase"
              >
                <Sparkles className="h-3 w-3 fill-current" />
                <span>Swipe Deck</span>
              </button>
            </div>

            {/* List entries */}
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-gray-550 pl-1 font-mono">
                <span>FAVORITED INSIGHTS</span>
                <span>{savedItems.length} SAVED</span>
              </div>

              <div className="grid grid-cols-1 gap-3.5">
                {savedItems.map((item) => (
                  <div
                    id={`saved-card-${item.id}`}
                    key={item.id}
                    className="glass-panel p-5 rounded-[28px] border border-white/10 bg-white/4 flex flex-col justify-between space-y-3 relative overflow-hidden group"
                  >
                    {/* Glowing Accent dot in background */}
                    <div 
                      className="absolute right-[-10px] top-[-10px] w-12 h-12 rounded-full blur-xl opacity-10 pointer-events-none"
                      style={{ backgroundColor: item.glowColor }}
                    />

                    <div className="flex items-center justify-between w-full">
                      <span className="font-mono text-[8px] uppercase tracking-[0.16em] text-[#D4AF37] font-bold bg-[#D4AF37]/10 px-2 py-0.5 rounded border border-[#D4AF37]/15">
                        {item.category}
                      </span>
                      
                      <button
                        id={`btn-saved-delete-${item.id}`}
                        onClick={() => onToggleFavorite(item.id)}
                        className="text-stone-500 hover:text-red-400 p-1 rounded-full transition-colors focus:outline-none"
                        title="Remove from favorites"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>

                    <p className="font-serif text-sm text-stone-100 leading-relaxed font-light">
                      "{item.text}"
                    </p>

                    <p className="font-sans text-[10px] text-stone-500 font-light text-left pl-1">
                      By {item.author || 'Ritual Engine'}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="immersive-swiper"
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.96 }}
            className="space-y-6"
          >
            {/* Header info */}
            <div className="flex items-center">
              <button
                id="btn-return-saved-list"
                onClick={() => setActivePlayDeck(false)}
                className="flex items-center space-x-1.5 font-display text-[10px] tracking-[0.15em] uppercase text-stone-400 hover:text-[#D4AF37] transition-colors"
              >
                <ChevronLeft className="h-4.5 w-4.5" />
                <span>Return to List</span>
              </button>
            </div>

            {/* Render the CardSwiper using ONLY the favorites subset! */}
            <CardSwiper
              affirmations={savedItems}
              favorites={progress.favorites}
              onToggleFavorite={onToggleFavorite}
              fontStyle={fontStyle}
              onChangeFontStyle={onChangeFontStyle}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
