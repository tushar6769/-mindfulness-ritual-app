/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Heart, SlidersHorizontal, Sparkles, ChevronLeft, Quote, Copy, Check } from 'lucide-react';
import { Affirmation, UserProgress } from '../types';
import { AFFIRMATIONS } from '../data';

interface ExploreScreenProps {
  progress: UserProgress;
  onToggleFavorite: (id: string) => void;
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  fontStyle: 'serif' | 'display' | 'sans';
}

const ALL_CATEGORIES = [
  { id: 'all', label: 'All' },
  { id: 'self-love', label: 'Self Love' },
  { id: 'confidence', label: 'Confidence' },
  { id: 'success', label: 'Success' },
  { id: 'discipline', label: 'Discipline' },
  { id: 'fitness', label: 'Fitness' },
  { id: 'gratitude', label: 'Gratitude' },
  { id: 'health', label: 'Health' },
  { id: 'study', label: 'Study' },
];

export default function ExploreScreen({
  progress,
  onToggleFavorite,
  selectedCategory,
  onSelectCategory,
  fontStyle
}: ExploreScreenProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeAffirmationModal, setActiveAffirmationModal] = useState<Affirmation | null>(null);
  const [modalCopied, setModalCopied] = useState(false);

  // Compute filtered items
  const filteredAffirmations = useMemo(() => {
    return AFFIRMATIONS.filter((item) => {
      // 1. Category Filter
      const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;

      // 2. Search Query Filter
      const matchesSearch = item.text.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (item.author && item.author.toLowerCase().includes(searchQuery.toLowerCase()));

      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchQuery]);

  const handleModalCopy = (item: Affirmation) => {
    navigator.clipboard.writeText(`"${item.text}" — ${item.author || 'Daily Ritual'}`);
    setModalCopied(true);
    setTimeout(() => setModalCopied(false), 2000);
  };  return (
    <div className="relative w-full flex flex-col space-y-6 pb-24 select-none">
      {/* Title */}
      <div className="space-y-1">
        <span className="font-mono text-[9px] uppercase tracking-[0.25em] text-[#D4AF37]/75 font-semibold">Universe Library</span>
        <h2 className="font-serif text-2xl font-normal text-white">Explore Anchorings</h2>
      </div>

      {/* Styled Interactive Search Block */}
      <div className="relative flex items-center w-full">
        <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
          <Search className="h-4.5 w-4.5 text-stone-550" />
        </div>
        <input
          id="search-explore-input"
          type="text"
          placeholder="Search keywords (e.g. power, quiet, respect)"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full h-12 pl-11 pr-4 rounded-full border border-white/10 bg-white/5 text-white placeholder-stone-605 font-display text-xs tracking-wide focus:outline-none focus:border-[#D4AF37]/50 focus:ring-1 focus:ring-[#D4AF37]/20 transition-all"
        />
      </div>

      {/* Categories Horizontal Scrolling Container */}
      <div className="w-full overflow-x-auto py-1 pl-1 pr-6 flex items-center space-x-2 scrollbar-none">
        {ALL_CATEGORIES.map((cat) => {
          const isActive = selectedCategory === cat.id;
          return (
            <button
              id={`cat-chip-${cat.id}`}
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`px-4.5 h-9 rounded-full font-display text-xs tracking-wider transition-all duration-300 flex items-center space-x-1.5 shrink-0 select-none ${
                isActive
                  ? 'bg-[#D4AF37] text-black border border-[#D4AF37]/80 font-semibold shadow-[0_4px_12px_rgba(212,175,55,0.3)]'
                  : 'bg-white/5 border border-white/10 text-stone-400 hover:text-white hover:bg-white/8'
              }`}
            >
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Micro Grid List Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs text-gray-500 pl-1 font-mono">
          <span>MATCHING SHARDS</span>
          <span>{filteredAffirmations.length} ITEMS</span>
        </div>

        <div className="grid grid-cols-1 gap-3">
          <AnimatePresence mode="popLayout">
            {filteredAffirmations.map((item) => {
              const favorited = progress.favorites.includes(item.id);
              return (
                <motion.div
                  id={`explore-item-${item.id}`}
                  key={item.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.35 }}
                  onClick={() => setActiveAffirmationModal(item)}
                  className="glass-panel p-4.5 rounded-[28px] border border-white/10 bg-white/4 hover:bg-white/8 hover:border-white/15 cursor-pointer transition-all flex justify-between items-start group relative overflow-hidden"
                >
                  {/* Subtle hover glow strip */}
                  <div 
                    className="absolute bottom-0 left-0 right-0 h-[2px] transition-all duration-500 bg-transparent group-hover:h-[3px]"
                    style={{ backgroundColor: item.glowColor }}
                  />

                  <div className="space-y-2 max-w-[85%]">
                    <span className="font-mono text-[8px] uppercase tracking-[0.16em] text-[#D4AF37]/80 font-semibold">
                      {item.category}
                    </span>
                    <p className={`font-serif text-sm text-stone-100 leading-relaxed font-light line-clamp-2`}>
                      "{item.text}"
                    </p>
                    <p className="font-sans text-[10px] text-stone-500 font-light">By {item.author || 'Ritual Engine'}</p>
                  </div>

                  <button
                    id={`btn-explore-heart-${item.id}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleFavorite(item.id);
                    }}
                    className={`p-2 rounded-full border transition-all ${
                      favorited
                        ? 'bg-[#D4AF37]/15 border-[#D4AF37]/35 text-[#D4AF37]'
                        : 'bg-white/5 border-white/10 text-stone-500 hover:text-white'
                    }`}
                  >
                    <Heart className={`h-3.5 w-3.5 ${favorited ? 'fill-current' : ''}`} />
                  </button>
                </motion.div>
              );
            })}
          </AnimatePresence>

          {filteredAffirmations.length === 0 && (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <Sparkles className="h-8 w-8 text-stone-700 stroke-1 mb-2" />
              <p className="font-serif text-sm text-stone-450">The forest is quiet.</p>
              <p className="text-[11px] text-stone-600 mt-0.5">We found no affirmations matching that query.</p>
            </div>
          )}
        </div>
      </div>

      {/* FULL-SCREEN IMMERSIVE SINGLE CARD MODAL VIEW */}
      <AnimatePresence>
        {activeAffirmationModal && (
          <motion.div
            id="explore-modal-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/98 p-6 backdrop-blur-2xl"
          >
            {/* Ambient Background Blur orb inside the modal */}
            <div 
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 rounded-full blur-[90px] opacity-25 bg-[#D4AF37]/10 transition-all pointer-events-none"
            />

            <div className="absolute top-11 left-6">
              <button
                id="btn-close-explore-modal"
                onClick={() => {
                  setActiveAffirmationModal(null);
                  setModalCopied(false);
                }}
                className="flex items-center space-x-1.5 font-display text-[10px] tracking-[0.15em] uppercase text-stone-400 hover:text-[#D4AF37] transition-colors"
               >
                <ChevronLeft className="h-4.5 w-4.5" />
                <span>Return</span>
              </button>
            </div>

            <motion.div
              id="explore-modal-card"
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              transition={{ type: 'spring', damping: 25, stiffness: 350 }}
              className="relative w-full max-w-sm rounded-[44px] p-8 h-[420px] flex flex-col justify-between border border-white/10 overflow-hidden shadow-[0_30px_70px_-15px_rgba(0,0,0,0.95)] glass-panel"
            >
              {/* Card gradient background */}
              <div 
                className="absolute inset-0 z-0 opacity-95"
                style={{
                  background: `linear-gradient(135deg, ${activeAffirmationModal.gradientFrom} 0%, #0c0c0c 70%, ${activeAffirmationModal.gradientTo} 100%)`
                }}
              />
              
              <div className="absolute inset-0 z-0 bg-gradient-to-b from-white/5 to-transparent pointer-events-none" />

              {/* Quote decoration */}
              <div className="relative z-10 flex w-full justify-between items-center">
                <div className="w-9 h-9 rounded-full bg-white/5 flex items-center justify-center border border-white/10">
                  <Quote className="h-4 w-4 text-[#D4AF37]" />
                </div>
                <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-[#D4AF37] font-semibold bg-[#D4AF37]/10 px-2.5 py-1 rounded-full border border-[#D4AF37]/15">
                  {activeAffirmationModal.category}
                </span>
              </div>

              {/* Text Block */}
              <div className="relative z-10 my-auto text-left py-2 select-text">
                <p 
                  className={`leading-relaxed text-white ${
                    fontStyle === 'serif' ? 'font-serif text-2xl font-light italic' :
                    fontStyle === 'display' ? 'font-display text-xl font-medium tracking-wide' : 'font-sans text-lg'
                  }`}
                >
                  "{activeAffirmationModal.text}"
                </p>
              </div>

              {/* Action Buttons row inside modal */}
              <div className="relative z-10 flex w-full justify-between items-center">
                <div>
                  <p className="font-mono text-[8px] uppercase tracking-widest text-[#D4AF37]/80 font-semibold">ANCHORED BY</p>
                  <p className="font-sans text-xs text-stone-300 mt-0.5 font-medium">{activeAffirmationModal.author || 'Daily Ritual'}</p>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    id="btn-copy-modal"
                    onClick={() => handleModalCopy(activeAffirmationModal)}
                    className={`w-10 h-10 rounded-full flex items-center justify-center border transition-all ${
                      modalCopied
                        ? 'bg-[#D4AF37]/15 border-[#D4AF37]/40 text-[#D4AF37] font-semibold'
                        : 'bg-white/5 border border-white/10 text-stone-400 hover:text-white'
                    }`}
                    title="Copy Affirmation"
                  >
                    {modalCopied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                  </button>

                  <button
                    id="btn-fav-modal"
                    onClick={() => {
                      onToggleFavorite(activeAffirmationModal.id);
                    }}
                    className={`w-10 h-10 rounded-full flex items-center justify-center border transition-all ${
                      progress.favorites.includes(activeAffirmationModal.id)
                        ? 'bg-[#D4AF37] border-[#D4AF37]/80 text-black shadow-[0_0_12px_rgba(212,175,55,0.4)]'
                        : 'bg-white/5 border border-white/10 text-stone-400 hover:text-white'
                    }`}
                    title="Favorite Affirmation"
                  >
                    <Heart
                      className={`h-4 w-4 ${
                        progress.favorites.includes(activeAffirmationModal.id) ? 'fill-current' : ''
                      }`}
                    />
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
