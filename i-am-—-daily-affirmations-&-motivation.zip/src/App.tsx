/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, X, Heart, ChevronLeft, RefreshCw, Moon, Quote } from 'lucide-react';
import { TabType, UserProgress, Affirmation } from './types';
import { INITIAL_USER_PROGRESS, getLocalDateString, getAffirmationOfTheDay, AFFIRMATIONS } from './data';
import Onboarding from './components/Onboarding';
import BottomNavbar from './components/BottomNavbar';
import HomeScreen from './components/HomeScreen';
import ExploreScreen from './components/ExploreScreen';
import SavedScreen from './components/SavedScreen';
import StreakScreen from './components/StreakScreen';
import CardSwiper from './components/CardSwiper';

export default function App() {
  const [progress, setProgress] = useState<UserProgress>(INITIAL_USER_PROGRESS);
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [immersiveAffirmation, setImmersiveAffirmation] = useState<Affirmation | null>(null);

  // Load user progress from localStorage on mount and run a streak audit
  useEffect(() => {
    const raw = localStorage.getItem('iam_manifest_prod');
    if (raw) {
      try {
        const parsed: UserProgress = JSON.parse(raw);
        
        // Ensure arrays are present to avoid runtime errors
        parsed.favorites = parsed.favorites || [];
        parsed.readHistory = parsed.readHistory || [];

        // Dynamic streak check: If the user hasn't check-in today OR yesterday, reset streak!
        const todayStr = getLocalDateString();
        const yesterdayObj = new Date();
        yesterdayObj.setDate(yesterdayObj.getDate() - 1);
        const yesterdayStr = getLocalDateString(yesterdayObj);

        if (parsed.lastActiveDate && parsed.lastActiveDate !== todayStr && parsed.lastActiveDate !== yesterdayStr) {
          parsed.streakCount = 0; // Missed yesterday and today, split unbroken streak
        }

        setProgress(parsed);
      } catch (err) {
        console.error('Failed to parse storage, using initial progress', err);
        setProgress(INITIAL_USER_PROGRESS);
      }
    } else {
      setProgress(INITIAL_USER_PROGRESS);
    }
  }, []);

  // Sync state to localStorage whenever it changes
  const saveProgressState = (newProgress: UserProgress) => {
    setProgress(newProgress);
    localStorage.setItem('iam_manifest_prod', JSON.stringify(newProgress));
  };

  // Onboarding completion
  const handleOnboardingComplete = (name: string, preferredCategory: string) => {
    const todayStr = getLocalDateString();
    
    const initialProgress: UserProgress = {
      onboardingCompleted: true,
      name,
      favorites: [],
      streakCount: 1, // Start with 1 day streak upon completion!
      lastActiveDate: todayStr,
      readHistory: [todayStr],
      preferredCategory,
      fontStyle: 'serif'
    };

    setSelectedCategory(preferredCategory);
    saveProgressState(initialProgress);
  };

  // Toggle favorite helper
  const handleToggleFavorite = (id: string) => {
    const isFav = progress.favorites.includes(id);
    const nextFavorites = isFav
      ? progress.favorites.filter((favId) => favId !== id)
      : [...progress.favorites, id];

    saveProgressState({
      ...progress,
      favorites: nextFavorites
    });
  };

  // Record daily check-in
  const handleRecordCheckIn = () => {
    const todayStr = getLocalDateString();
    if (progress.readHistory.includes(todayStr)) return; // Already completed today

    const newHistory = [...progress.readHistory, todayStr];
    
    // Check if the last check-in was yesterday to increment streak
    const yesterdayObj = new Date();
    yesterdayObj.setDate(yesterdayObj.getDate() - 1);
    const yesterdayStr = getLocalDateString(yesterdayObj);

    let nextStreak = progress.streakCount;
    if (progress.lastActiveDate === yesterdayStr) {
      nextStreak += 1;
    } else if (progress.lastActiveDate !== todayStr) {
      // Streak was broken, start fresh with 1
      nextStreak = 1;
    }

    saveProgressState({
      ...progress,
      streakCount: nextStreak,
      lastActiveDate: todayStr,
      readHistory: newHistory
    });
  };

  // Reset progress helper for testing and judges
  const handleResetData = () => {
    if (window.confirm('Do you want to reset your meditation sequence? This will restore onboarding.')) {
      localStorage.removeItem('iam_manifest_prod');
      setProgress(INITIAL_USER_PROGRESS);
      setActiveTab('home');
      setSelectedCategory('all');
      setImmersiveAffirmation(null);
    }
  };

  const handleUpdateFontStyle = (style: 'serif' | 'display' | 'sans') => {
    saveProgressState({
      ...progress,
      fontStyle: style
    });
  };

  // Filter affirmations matching the user preference or general list
  const activeFocusAffirmations = React.useMemo(() => {
    if (selectedCategory === 'all') return AFFIRMATIONS;
    return AFFIRMATIONS.filter(a => a.category === selectedCategory);
  }, [selectedCategory]);

  // If onboarding is not completed, display onboarding flow
  if (!progress.onboardingCompleted) {
    return (
      <Onboarding onComplete={handleOnboardingComplete} />
    );
  }

  return (
    <div className="relative min-h-screen w-full bg-[#080808] text-white overflow-x-hidden font-sans select-none pb-24">
      {/* Dynamic Dramatic Gradient background / Ambient Orbs */}
      <div className="inset-0 absolute z-0 overflow-hidden pointer-events-none">
        {/* Floating Orb 1: Luxury Gold */}
        <motion.div
          animate={{
            x: [-40, 30, -10, 50, -40],
            y: [-25, 70, -35, 15, -25],
          }}
          transition={{
            duration: 22,
            repeat: Infinity,
            repeatType: 'mirror',
            ease: 'easeInOut',
          }}
          className="absolute top-1/6 left-1/4 w-80 h-80 rounded-full bg-[#D4AF37]/8 blur-[120px]"
        />

        {/* Floating Orb 2: Deep Orange Copper */}
        <motion.div
          animate={{
            x: [40, -20, 30, -40, 40],
            y: [50, -15, 45, -30, 50],
          }}
          transition={{
            duration: 26,
            repeat: Infinity,
            repeatType: 'mirror',
            ease: 'easeInOut',
          }}
          className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-orange-950/20 blur-[130px]"
        />
      </div>

      {/* Main Container */}
      <div className="relative z-10 w-full max-w-md mx-auto px-5.5 pt-7 pb-20">
        
        {/* Minimal branding top menu */}
        <header className="flex justify-between items-center mb-6 relative select-none">
          <div className="flex items-center space-x-2">
            <div className="w-6.5 h-6.5 rounded-[8px] bg-stone-900 border border-stone-800 flex items-center justify-center">
              <Sparkles className="h-3 w-3 text-amber-400" />
            </div>
            <span className="font-display text-[10px] tracking-[0.25em] text-white/90 font-bold uppercase">I AM</span>
          </div>

          <div className="flex items-center space-x-3.5">
            {/* Quick configuration toggle: Switch font directly */}
            <span className="text-[10px] text-stone-500 font-mono tracking-wider font-semibold bg-stone-950 px-2 py-0.5 rounded border border-stone-900">
              {progress.streakCount}D STREAK
            </span>

            {/* Custom Dev reset sequence */}
            <button
              id="btn-global-reset"
              onClick={handleResetData}
              className="text-stone-550 hover:text-red-400 p-1.5 rounded-full hover:bg-stone-950 transition-all border border-transparent hover:border-stone-900"
              title="Reset Alignment Sequence"
            >
              <RefreshCw className="h-3.5 w-3.5" />
            </button>
          </div>
        </header>

        {/* Dynamic Nav Tabs Body */}
        <div id="tabs-deck-wrapper" className="min-h-[500px]">
          <AnimatePresence mode="wait">
            {activeTab === 'home' && (
              <motion.div
                key="home-tab"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.45, ease: 'easeOut' }}
              >
                <HomeScreen
                  progress={progress}
                  onChangeTab={setActiveTab}
                  onSelectCategory={setSelectedCategory}
                  onOpenImmersive={(aff) => setImmersiveAffirmation(aff)}
                />
              </motion.div>
            )}

            {activeTab === 'explore' && (
              <motion.div
                key="explore-tab"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.45, ease: 'easeOut' }}
              >
                <ExploreScreen
                  progress={progress}
                  onToggleFavorite={handleToggleFavorite}
                  selectedCategory={selectedCategory}
                  onSelectCategory={setSelectedCategory}
                  fontStyle={progress.fontStyle}
                />
              </motion.div>
            )}

            {activeTab === 'saved' && (
              <motion.div
                key="saved-tab"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.45, ease: 'easeOut' }}
              >
                <SavedScreen
                  progress={progress}
                  onToggleFavorite={handleToggleFavorite}
                  fontStyle={progress.fontStyle}
                  onChangeFontStyle={handleUpdateFontStyle}
                  onChangeTab={setActiveTab}
                />
              </motion.div>
            )}

            {activeTab === 'streak' && (
              <motion.div
                key="streak-tab"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.45, ease: 'easeOut' }}
              >
                <StreakScreen
                  progress={progress}
                  onRecordCheckIn={handleRecordCheckIn}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* FIXED BOTTOM NATIVE NAVBAR */}
      <BottomNavbar
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        favoritesCount={progress.favorites.length}
        streakCount={progress.streakCount}
      />

      {/* FULL-SCREEN OVERLAY FOR IMMERSIVE TRANSITIONS (Tapped from home daily card) */}
      <AnimatePresence>
        {immersiveAffirmation && (
          <motion.div
            id="immersive-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex flex-col justify-between bg-black/98 p-6 backdrop-blur-2xl"
          >
            {/* Top close button */}
            <div className="z-10 flex justify-between items-center pt-8">
              <button
                id="btn-close-immersive"
                onClick={() => setImmersiveAffirmation(null)}
                className="flex items-center space-x-1.5 text-stone-400 hover:text-amber-400 font-display text-[11px] uppercase tracking-widest font-semibold"
              >
                <ChevronLeft className="h-4.5 w-4.5" />
                <span>Dismiss</span>
              </button>

              <span className="font-mono text-[9px] text-[#d4af37] tracking-[0.2em]">IMMERSION SPACE</span>
            </div>

            {/* Immersive View holds CardSwiper focused on this affirmation category */}
            <div className="my-auto">
              <CardSwiper
                affirmations={[immersiveAffirmation, ...AFFIRMATIONS.filter(t => t.id !== immersiveAffirmation.id && t.category === immersiveAffirmation.category)]}
                favorites={progress.favorites}
                onToggleFavorite={handleToggleFavorite}
                fontStyle={progress.fontStyle}
                onChangeFontStyle={handleUpdateFontStyle}
              />
            </div>

            <div className="pb-10 text-center text-stone-600 font-mono text-[8px] tracking-[0.25em] uppercase">
              BREATHE SECURELY • ALIGN FREQUENCY
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
