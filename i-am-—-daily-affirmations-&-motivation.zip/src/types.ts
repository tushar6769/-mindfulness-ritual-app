/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Affirmation {
  id: string;
  text: string;
  category: 'confidence' | 'success' | 'health' | 'gratitude' | 'study' | 'discipline' | 'self-love' | 'fitness';
  author?: string;
  gradientFrom: string;
  gradientTo: string;
  glowColor: string; // e.g. rgba(212, 175, 55, 0.2) or hex code for golden glow
}

export interface UserProgress {
  onboardingCompleted: boolean;
  name: string;
  favorites: string[]; // List of affirmation IDs
  streakCount: number;
  lastActiveDate: string; // YYYY-MM-DD format
  readHistory: string[]; // dates when active, e.g. ["2026-05-25", "2026-05-26"]
  preferredCategory: string; // 'all' or specific category
  fontStyle: 'serif' | 'display' | 'sans';
}

export type TabType = 'home' | 'explore' | 'saved' | 'streak';
